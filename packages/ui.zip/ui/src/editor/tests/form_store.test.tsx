// import { catalogueEditor } from '../../catalogue_editor';
// import {
//   baseForm,
//   baseSchema,
//   personSchema,
//   signatureSchema,
//   someSchema
// } from '../../semantic/tests/fixtures';
// import { catalogue } from '../../catalogue';
// import { EditorState } from '../editor_state';

// let types = [
//   {
//     id: 'p1',
//     name: 'Person',
//     description: 'Private records of a person',
//     schema: personSchema
//   },
//   {
//     id: 's1',
//     name: 'Signature',
//     description: 'Description',
//     schema: signatureSchema
//   },
//   {
//     id: 'o1',
//     name: 'Other Schema',
//     description: 'Some other schema',
//     schema: someSchema
//   }
// ];

// describe('Form Store', () => {
//   // it('creates store with various control props', () => {
//   //   const state = new EditorState(catalogue, catalogueEditor, null, types);
//   //   let m = state.buildProject(baseForm, baseSchema);
//   //   console.log(m.form.elements[0].props.rows);
//   // });
// });
