interface Function {
  displayName: string;
  childContextTypes: any;
  contextTypes: any;
  propTypes: any;
  defaultProps: any;
}
