// import { FormElement, DataSet, EditorFormComponentCatalogue, Handlers } from '@toryjs/form';

export type Validation = (value: string) => string;

// export type ControlProps = {
//   control: FormElement;
//   readOnly?: boolean;
//   owner: DataSet;
//   handlers: Handlers<FormElement>;
//   renderControl?: (formElement: FormElement, owner: DataSet) => JSX.Element;
// };

// export type ComposedControlProps = {
//   control: FormElement;
//   owner: DataSet;
//   renderElements: (elements: FormElement[], owner: DataSet, addLabel?: boolean) => any;
//   catalogue: EditorFormComponentCatalogue;
// };
